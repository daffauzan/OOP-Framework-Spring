package com.example.ecommerce.controllers;

import com.example.ecommerce.models.User;
import com.example.ecommerce.models.UserDto;
import com.example.ecommerce.services.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserRepository userRepo;

    @GetMapping({"", "/"})
    public String showUserList(Model model) {
        List<User> users = userRepo.findAll();
        model.addAttribute("users", users);
        return "admin/listUser";
    }   
    
    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password, Model model) {
        Optional<User> userOptional = userRepo.findByUsernameAndPassword(username, password);

        if (userOptional.isPresent()) {
            return "users/home"; // Redirect to the post-login page
        } else {
            model.addAttribute("error", "Invalid username or password");
            return "login/User"; // Return to the login page with an error message
        }
    }

    @GetMapping("/create")
    public String showCreateUserForm(Model model) {
        model.addAttribute("userDto", new UserDto());
        return "admin/CreateUser";
    }

    @PostMapping("/create")
    public String createUserSubmit(@ModelAttribute("userDto") @Valid UserDto userDto,
                                   BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "admin/CreateUser";
        }

        // Save userDto to the database using UserRepository
        User newUser = new User();
        newUser.setUsername(userDto.getUsername());
        newUser.setPassword(userDto.getPassword()); // Consider hashing the password
        newUser.setCreateAt(new Date());

        userRepo.save(newUser);

        return "redirect:/users"; // Redirect to the user list page or another appropriate page
    }

    @GetMapping("/edit/{id}")
    public String editUserForm(@PathVariable("id") int id, Model model) {
        Optional<User> optionalUser = userRepo.findById(id);
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            UserDto userDto = new UserDto();
            userDto.setId(user.getId());
            userDto.setUsername(user.getUsername());
            userDto.setPassword(user.getPassword());
            userDto.setCreateAt(user.getCreateAt());

            model.addAttribute("userDto", userDto);
            return "admin/EditUser";
        } else {
            // Handle user not found error
            return "redirect:/users";
        }
    }

    @PostMapping("/edit/{id}")
    public String editUserSubmit(@PathVariable("id") int id,
                                 @ModelAttribute("userDto") @Valid UserDto userDto,
                                 BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "admin/EditUser";
        }

        Optional<User> optionalUser = userRepo.findById(id);
        if (optionalUser.isPresent()) {
            User existingUser = optionalUser.get();
            existingUser.setUsername(userDto.getUsername());
            // Consider hashing the password
            existingUser.setPassword(userDto.getPassword());

            userRepo.save(existingUser);

            return "redirect:/users";
        } else {
            // Handle user not found error
            return "redirect:/users";
        }
    }

    @GetMapping("/delete/{id}")
    public String deleteUser(@PathVariable("id") int id) {
        userRepo.deleteById(id);
        return "redirect:/users";
    }
}
