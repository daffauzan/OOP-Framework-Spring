package com.example.ecommerce.controllers;

import com.example.ecommerce.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/shop")
public class ShopController {
    
    @Autowired
    private ProductService productService;

    @GetMapping({"", "/"})
    public String shopPage(Model model) {
        model.addAttribute("products", productService.getAllProducts());
        return "users/shop";
    }
    
    @GetMapping("/home")
    public String showHome(Model model) {
        return "users/home";
    }
    
    @GetMapping("/about")
    public String showAbout(Model model) {
        return "users/about";
    }
    
}
