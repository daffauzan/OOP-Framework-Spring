package com.example.ecommerce.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

import java.util.Date;

@Entity
@Table (name="transaksi")
public class Transaksi {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@NotNull
	private String nama;

	@ManyToOne(fetch = FetchType.LAZY) // Use FetchType.LAZY if possible
	@JoinColumn(name = "product_id", nullable = false)
	private Product product;
	
	@NotNull
	private int quantity;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at")
    private Date createdAt = new Date();
	
	private boolean sudahDibayar;
	
	public boolean isSudahDibayar() {
		return sudahDibayar;
	}

	public void setSudahDibayar(boolean sudahDibayar) {
		this.sudahDibayar = sudahDibayar;
	}

	public Transaksi() {
        this.createdAt = new Date();
    }
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNama() {
		return nama;
	}

	public void setNama(String nama) {
		this.nama = nama;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public void setCreatedAt(Date date) {
		// TODO Auto-generated method stub
		
	}

	public Date getCreatedAt() {
		// TODO Auto-generated method stub
		return null;
	}

}
