package com.example.ecommerce.controllers;

import com.example.ecommerce.models.Product;
import com.example.ecommerce.models.Transaksi;
import com.example.ecommerce.models.TransaksiDto;
import com.example.ecommerce.services.TransaksiRepository;

import jakarta.validation.Valid;

import com.example.ecommerce.services.ProductRepository;
import com.example.ecommerce.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/transaksi")
public class TransaksiController {
	
	 @Autowired
	 private TransaksiRepository transaksirepo;
	 
	 @Autowired
	 private ProductService productservice;
	 
	 @Autowired
	 private ProductRepository productrepo;
	 
	 @GetMapping({"", "/"})
	 public String showTransaksiList(Model model) {
		 List<Transaksi> transaksiList = transaksirepo.findAll();
		 model.addAttribute("transaksiList", transaksiList);
		 return "transaksi/index";
	 }
	 
	 @GetMapping("/create")
	 public String showCreateTransaksiPage(Model model) {
	     TransaksiDto transaksiDto = new TransaksiDto();
	     model.addAttribute("transaksiDto", transaksiDto);  
	     model.addAttribute("products", productservice.getAllProducts());
	     return "transaksi/CreateTransaksi";
	 }
	 
	 @PostMapping("/create")
	 public String createTransaksi(@ModelAttribute @Valid TransaksiDto transaksiDto,
             BindingResult bindingResult,
             Model model) {
				
				if (bindingResult.hasErrors()) {
						return "transaksi/create";
						}
				
				Transaksi transaksi = new Transaksi();
				transaksi.setNama(transaksiDto.getNama());
				transaksi.setQuantity(transaksiDto.getQuantity());
				
				Product product = productrepo.findById(transaksiDto.getProductId())
				.orElseThrow(() -> new IllegalArgumentException("Invalid product ID"));
				
				try {
				product.reduceStock(transaksiDto.getQuantity());
				transaksi.setProduct(product);
				transaksirepo.save(transaksi);
				
				} catch (IllegalArgumentException e) {
				model.addAttribute("errorMessage", e.getMessage());
				return "transaksi/create";
				}

	 return "redirect:/shop";
	}
	 
	 @GetMapping("/konfirmasi/{id}")
	 public String showKonfirmasiPembayaranPage(Model model, @PathVariable int id) {
	     Transaksi transaksi = transaksirepo.findById(id)
	             .orElseThrow(() -> new IllegalArgumentException("Invalid transaksi ID: " + id));
	     
	     TransaksiDto transaksiDto = new TransaksiDto();
	     transaksiDto.setId(transaksi.getId());
	     transaksiDto.setNama(transaksi.getNama());
	     transaksiDto.setProductId(transaksi.getProduct().getId());
	     transaksiDto.setQuantity(transaksi.getQuantity());
	     transaksiDto.setCreatedAt(transaksi.getCreatedAt());
	     transaksiDto.setSudahDibayar(transaksi.isSudahDibayar());

	     model.addAttribute("transaksiDto", transaksiDto);
	     model.addAttribute("products", productservice.getAllProducts()); // Untuk dropdown produk

	     return "/transaksi";
	 }
		 
	 @PostMapping("/konfirmasi/{id}")
	 public String konfirmasiPembayaran(
	         @Valid @ModelAttribute TransaksiDto transaksiDto,
	         BindingResult result,
	         Model model,
	         @PathVariable int id) {

	     if (result.hasErrors()) {
	         model.addAttribute("products", productservice.getAllProducts()); // For dropdown product
	         return "transaksi"; // Return the form again with validation errors
	     }

	     Transaksi transaksi = transaksirepo.findById(id)
	             .orElseThrow(() -> new IllegalArgumentException("Invalid transaksi ID: " + id));

	     transaksi.setNama(transaksiDto.getNama());
	     transaksi.setProduct(productservice.getProductById(transaksiDto.getProductId()));
	     transaksi.setQuantity(transaksiDto.getQuantity());
	     transaksi.setCreatedAt(transaksiDto.getCreatedAt());
	     transaksi.setSudahDibayar(true);

	     transaksirepo.save(transaksi);

	     return "redirect:/transaksi"; // Redirect to your list page
	 }

	 
	 @PostMapping("/delete/{id}")
	    public String deleteTransaksi(@PathVariable int id) {
		 Transaksi transaksi = transaksirepo.findById(id)
	                .orElseThrow(() -> new IllegalArgumentException("Invalid transaction ID"));

	        Product product = transaksi.getProduct();
	        int quantity = transaksi.getQuantity();

	        product.increaseStock(quantity); // Mengembalikan stok produk
	        productrepo.save(product); // Menyimpan perubahan stok produk ke database

	        transaksirepo.deleteById(id); // Menghapus transaksi dari database

	        return "redirect:/transaksi";
	    }
}
