package com.example.ecommerce.models;

import java.util.Date;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public class TransaksiDto {
	
	@NotEmpty(message = "Masukkan nama pembeli")
	private String nama;
    
    private int productId;
    
    @NotNull(message = "Masukkan jumlah yang akan dibeli")
    @Min(value = 1, message = "Quantity must be greater than 0")
    private int quantity;
    
    private boolean sudahDibayar;
    
    public boolean isSudahDibayar() {
		return sudahDibayar;
	}

	public void setSudahDibayar(boolean sudahDibayar) {
		this.sudahDibayar = sudahDibayar;
	}

	public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setCreatedAt(Date createdAt) {
        // Implementasikan jika diperlukan
    }

    public Date getCreatedAt() {
        // Implementasikan jika diperlukan
        return null;
    }

    public void setId(int id) {
        // Implementasikan jika diperlukan
    }

}
