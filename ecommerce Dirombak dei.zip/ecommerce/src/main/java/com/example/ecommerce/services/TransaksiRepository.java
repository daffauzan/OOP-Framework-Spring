package com.example.ecommerce.services;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ecommerce.models.Transaksi;


public interface TransaksiRepository extends JpaRepository<Transaksi, Integer>{


}
