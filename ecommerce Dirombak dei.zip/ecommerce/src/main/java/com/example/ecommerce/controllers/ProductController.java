package com.example.ecommerce.controllers;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.*;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.ecommerce.services.ProductRepository;

import jakarta.validation.Valid;

import com.example.ecommerce.models.Product;
import com.example.ecommerce.models.ProductDto;

@Controller
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductRepository repo;

    @GetMapping({"", "/"})
    public String showProductList(Model model) {
        List<Product> products = repo.findAll();
        model.addAttribute("products", products);
        return "products/index";
    }

    @GetMapping("/create")
    public String showCreatePage(Model model) {
        ProductDto productDto = new ProductDto();
        model.addAttribute("productDto", productDto);
        return "products/CreateProduct";
    }

    @PostMapping("/create")
    public String createProduct(
            @Valid @ModelAttribute ProductDto productDto,
            BindingResult result,
            Model model) {

        if (productDto.getImageFile().isEmpty()) {
            result.addError(new FieldError("productDto", "imageFile", "Masukkan Gambar!")); 
        }

        if (result.hasErrors()) {
            return "products/CreateProduct";
        }

        MultipartFile image = productDto.getImageFile();
        Date createdAt = new Date();
        String storageFileName = createdAt.getTime() + "_" + image.getOriginalFilename();

        try {
            String uploadDir = "public/images/";
            Path uploadPath = Paths.get(uploadDir);

            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            try (InputStream inputStream = image.getInputStream()) {
                Files.copy(inputStream, uploadPath.resolve(storageFileName),
                        StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception ex) {
            System.out.println("Exception: " + ex.getMessage());
        }

        Product product = new Product();
        product.setName(productDto.getName());
        product.setBrand(productDto.getBrand());
        product.setCategory(productDto.getCategory());
        product.setPrice(productDto.getPrice());
        product.setDescription(productDto.getDescription());
        product.setStock(productDto.getStock());
        product.setImageFilename(storageFileName);
        product.setCreatedAt(new Date());

        repo.save(product);

        return "redirect:/products";
    }

    @GetMapping("/edit")
    public String showEditPage(Model model, @RequestParam int id) {
        try {
            Product product = repo.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid product ID: " + id));
            ProductDto productDto = new ProductDto();
            productDto.setId(product.getId());
            productDto.setName(product.getName());
            productDto.setBrand(product.getBrand());
            productDto.setCategory(product.getCategory());
            productDto.setPrice(product.getPrice());
            productDto.setDescription(product.getDescription());
            productDto.setStock(product.getStock());
            productDto.setCreatedAt(product.getCreatedAt());
            productDto.setImageUrl("/images/" + product.getImageFilename());

            model.addAttribute("productDto", productDto);
        
        } catch (Exception ex) {
            System.out.println("Exception: " + ex.getMessage());
            return "redirect:/products";
        }

        return "/products/EditProducts"; // Ensure this matches the template file name
    }
    
    @PostMapping("/edit")
    public String editProduct(
            @Valid @ModelAttribute ProductDto productDto,
            BindingResult result,
            Model model,
            @RequestParam("imageFile") MultipartFile imageFile) {

        if (result.hasErrors()) {
            // Handle validation errors
            return "products/EditProduct";
        }

        Product product = repo.findById(productDto.getId())
                              .orElseThrow(() -> new IllegalArgumentException("Invalid product ID: " + productDto.getId()));

        product.setName(productDto.getName());
        product.setBrand(productDto.getBrand());
        product.setCategory(productDto.getCategory());
        product.setPrice(productDto.getPrice());
        product.setDescription(productDto.getDescription());
        product.setStock(productDto.getStock());
        product.setCreatedAt(productDto.getCreatedAt()); // Jika perlu diubah
        // Jika tidak ada perubahan pada gambar, tidak perlu mengubah imageFilename

        repo.save(product);

        return "redirect:/products";
    }
    
    @PostMapping("/delete")
    public String deleteProduct(@RequestParam("id") int id) {
        try {
            Product product = repo.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid product ID: " + id));
            repo.deleteById(id);

            // Delete the image file from the server
            String imageFileName = product.getImageFilename();
            String uploadDir = "public/images/";
            Path filePath = Paths.get(uploadDir, imageFileName);

            try {
                Files.deleteIfExists(filePath);
            } catch (IOException e) {
                System.out.println("Could not delete image file: " + e.getMessage());
            }

        } catch (Exception ex) {
            System.out.println("Exception: " + ex.getMessage());
        }

        return "redirect:/products";
    }


}


