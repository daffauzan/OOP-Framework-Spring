package com.example.ecommerce.services;

import com.example.ecommerce.models.UserDto;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Service;

import com.example.ecommerce.models.User;

@Service
public interface UserRepository extends JpaRepository<User, Integer>{

	Optional<User> findByUsernameAndPassword(String username, String password);

	Optional<User> findById(Long id);
	
	@Query("SELECT CASE WHEN COUNT(u) > 0 THEN true ELSE false END FROM User u WHERE u.username = :username")
    boolean existsByUsername(String username);
	
	public class UserService {

	    public void registerUser(UserDto userDto) {
	        // Implement user registration logic here
	        // This could involve saving the user data to a database, etc.
	    }
	}
}
