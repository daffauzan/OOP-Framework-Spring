package com.example.ecommerce.controllers;

import com.example.ecommerce.models.Admin;
import com.example.ecommerce.models.AdminDto;
import com.example.ecommerce.services.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/admins")
public class AdminController {
	
	@Autowired
    private AdminRepository adminRepo;

    @GetMapping({"", "/"})
    public String showAdminList(Model model) {
        List<Admin> admins = adminRepo.findAll();
        model.addAttribute("admins", admins);
        return "admin/listAdmin";
    }
    
    // Tampilkan halaman admin
    @GetMapping("/dashboard")
	public String adminDashboard(Model model) {
	    return "admin/dashboard";
	}
    
    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password, Model model) {
        Optional<Admin> adminOptional = adminRepo.findByUsernameAndPassword(username, password);
        if (adminOptional.isPresent()) {
            model.addAttribute("admin", adminOptional.get());
            return "redirect:/admin/AdminView"; // Redirect ke halaman dashboard admin
        } else {
            model.addAttribute("error", "Invalid username or password");
            return "login/admin";
        }
    }

    @GetMapping("/create")
    public String createAdminForm(Model model) {
        model.addAttribute("adminDto", new AdminDto());
        return "admin/CreateAdmin";
    }

    @PostMapping("/create")
    public String createAdminSubmit(@ModelAttribute("adminDto") @Valid AdminDto adminDto,
                                    BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "admin/CreateAdmin";
        }

        Admin newAdmin = new Admin();
        newAdmin.setUsername(adminDto.getUsername());
        // Disarankan menggunakan hashing untuk password
        newAdmin.setPassword(adminDto.getPassword());
        newAdmin.setCreateAt(new Date());

        adminRepo.save(newAdmin);

        return "redirect:/admins";
    }

    @GetMapping("/edit/{id}")
    public String editAdminForm(@PathVariable("id") Long id, Model model) {
        Optional<Admin> optionalAdmin = adminRepo.findById(id);
        if (optionalAdmin.isPresent()) {
            Admin admin = optionalAdmin.get();
            AdminDto adminDto = new AdminDto();
            adminDto.setId(admin.getId());
            adminDto.setUsername(admin.getUsername());
            adminDto.setPassword(admin.getPassword()); // Tidak disarankan mengirim password dalam DTO

            model.addAttribute("adminDto", adminDto);
            return "admin/EditAdmin";
        } else {
            // Handle admin not found error
            return "redirect:/admins";
        }
    }

    @PostMapping("/edit/{id}")
    public String editAdminSubmit(@PathVariable("id") Long id,
                                  @ModelAttribute("adminDto") @Valid AdminDto adminDto,
                                  BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "admin/EditAdmin";
        }

        Optional<Admin> optionalAdmin = adminRepo.findById(id);
        if (optionalAdmin.isPresent()) {
            Admin existingAdmin = optionalAdmin.get();
            existingAdmin.setUsername(adminDto.getUsername());
            // Disarankan menggunakan hashing untuk password
            existingAdmin.setPassword(adminDto.getPassword());
            // Anda bisa menambahkan logika untuk mengubah field lain jika diperlukan

            adminRepo.save(existingAdmin);

            return "redirect:/admins";
        } else {
            // Handle admin not found error
            return "redirect:/admins";
        }
    }

    @GetMapping("/delete/{id}")
    public String deleteAdmin(@PathVariable("id") int id) {
        adminRepo.deleteById(id);
        return "redirect:/admins";
    }
}
