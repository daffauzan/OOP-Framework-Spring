package com.example.ecommerce.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.ecommerce.models.Transaksi;
import com.example.ecommerce.models.Product;
import com.example.ecommerce.services.TransaksiRepository;
import com.example.ecommerce.services.ProductRepository;

import jakarta.validation.Valid;
import java.util.Date;

@Controller
@RequestMapping("/shop/transaksi")
public class TransaksiController {

    @Autowired
    private ProductRepository productRepo;

    @Autowired
    private TransaksiRepository transaksiRepo;

    @GetMapping
    public String showCreatePage(@RequestParam("productId") Long productId, Model model) {
        Transaksi transaksi = new Transaksi();
        Product product = productRepo.findById(productId).orElseThrow(() -> new IllegalArgumentException("Invalid product ID"));
        transaksi.setProduct(product);
        model.addAttribute("transaksi", transaksi);
        return "transaksi/CreateTransaksi";
    }

    @PostMapping("/create")
    public String createTransaksi(
            @Valid @ModelAttribute Transaksi transaksi,
            BindingResult result,
            Model model) {

        if (result.hasErrors()) {
            // Jika terdapat error validasi, kembalikan ke halaman form
            model.addAttribute("transaksi", transaksi);
            return "transaksi/CreateTransaksi";
        }

        // Update stock produk
        Product product = transaksi.getProduct();
        int newStock = product.getStock() - transaksi.getQuantity();
        if (newStock < 0) {
            result.rejectValue("quantity", "error.transaksi", "Insufficient stock");
            model.addAttribute("transaksi", transaksi);
            return "transaksi/CreateTransaksi";
        }
        product.setStock(newStock);
        productRepo.save(product);

        // Set tanggal transaksi
        transaksi.setCreatedAt(new Date());

        // Simpan transaksi ke dalam database
        transaksiRepo.save(transaksi);

        return "redirect:/shop/transaksi/list";
    }

    @GetMapping("/list")
    public String showTransaksiList(Model model) {
        model.addAttribute("transaksis", transaksiRepo.findAll());
        return "transaksi/index";
    }

    @GetMapping("/confirm")
    public String confirmTransaksi(@RequestParam("id") int id) {
        // Logika konfirmasi transaksi
        return "redirect:/transaksi";
    }

    @GetMapping("/cancel")
    public String cancelTransaksi(@RequestParam("id") int id) {
        Transaksi transaksi = transaksiRepo.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid transaction ID: " + id));
        Product product = transaksi.getProduct();
        
        // Kembalikan stock produk
        product.setStock(product.getStock() + transaksi.getQuantity());
        productRepo.save(product);

        // Hapus transaksi dari database
        transaksiRepo.delete(transaksi);
        return "redirect:/shop/transaksi/list";
    }
}
