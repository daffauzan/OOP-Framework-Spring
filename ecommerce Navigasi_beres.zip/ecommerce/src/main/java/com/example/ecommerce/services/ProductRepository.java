package com.example.ecommerce.services; // Untuk membaca dan write produk

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.ecommerce.models.Product;

public interface ProductRepository extends JpaRepository<Product, Integer>{

	void deleteById(Long id);

	Optional<Product> findById(Long id);

}
