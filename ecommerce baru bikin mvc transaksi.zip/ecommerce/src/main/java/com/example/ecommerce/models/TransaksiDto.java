package com.example.ecommerce.models;

import java.util.Date;
import jakarta.validation.constraints.NotEmpty;

public class TransaksiDto {
	
	@NotEmpty(message = "Masukkan nama pembeli")
	private String nama;
	
    private Product product;
    
    @NotEmpty(message = "Masukkan jumlah yang akan dibeli")
    private int quantity;
    
    private Date createdAt;

	public String getNama() {
		return nama;
	}

	public void setNama(String nama) {
		this.nama = nama;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public void setId(int id) {
		// TODO Auto-generated method stub
		
	}

	public void setProductId(int id) {
		// TODO Auto-generated method stub
		
	}

}
