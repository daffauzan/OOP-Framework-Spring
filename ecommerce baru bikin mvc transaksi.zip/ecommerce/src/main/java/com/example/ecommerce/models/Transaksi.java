package com.example.ecommerce.models;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table (name="transaksi")
public class Transaksi {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	private String nama;

	@ManyToOne
	@JoinColumn(name = "product_id", nullable = false)
	private Product product;
	
	private int quantity;
	
	@Temporal(TemporalType.TIMESTAMP)
    private Date createdAt = new Date();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNama() {
		return nama;
	}

	public void setNama(String nama) {
		this.nama = nama;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public void setCreatedAt(Date date) {
		// TODO Auto-generated method stub
		
	}

	public Date getCreatedAt() {
		// TODO Auto-generated method stub
		return null;
	}

}
