package com.example.ecommerce.services;

import com.example.ecommerce.models.Transaksi;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TransaksiRepository extends JpaRepository<Transaksi, Integer>{

}
