package com.example.ecommerce.controllers;

import com.example.ecommerce.models.Transaksi;
import com.example.ecommerce.models.TransaksiDto;
import com.example.ecommerce.services.TransaksiRepository;

import jakarta.validation.Valid;

import com.example.ecommerce.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/transaksi")
public class TransaksiController {
	
	 @Autowired
	 private TransaksiRepository transaksirepo;
	 
	 @Autowired
	 private ProductService productservice;
	 
	 @GetMapping({"", "/"})
	 public String showTransaksiList(Model model) {
		 List<Transaksi> transaksiList = transaksirepo.findAll();
		 model.addAttribute("transaksiList", transaksiList);
		 return "transaksi/index";
	 }
	 
	 @GetMapping("/create")
	 public String showCreateTransaksiPage(Model model) {
	     TransaksiDto transaksiDto = new TransaksiDto();
	     model.addAttribute("transaksiDto", transaksiDto);  
	     model.addAttribute("products", productservice.getAllProducts());
	     return "transaksi/CreateTransaksi";
	 }
	 
	 @PostMapping("/create")
	    public String createTransaksi(
	            @Valid @ModelAttribute TransaksiDto transaksiDto,
	            BindingResult result,
	            Model model) {
		 
		 if (result.hasErrors()) {
			 model.addAttribute("products", productservice.getAllProducts());
			 return "transaksi/CreateTransaksi";
		 }
		 
		 Transaksi transaksi = new Transaksi();
	     transaksi.setNama(transaksiDto.getNama());
	     transaksi.setProduct(productservice.getProductById(transaksiDto.getProduct()));
	     transaksi.setQuantity(transaksiDto.getQuantity());
	     transaksi.setCreatedAt(transaksiDto.getCreatedAt());

	     transaksirepo.save(transaksi);

	     return "redirect:/shop";
	 }
	 
	 @GetMapping("/edit/{id}")
	    public String showEditTransaksiPage(Model model, @PathVariable int id) {
	        Transaksi transaksi = transaksirepo.findById(id)
	                .orElseThrow(() -> new IllegalArgumentException("Invalid transaksi ID: " + id));
	        TransaksiDto transaksiDto = new TransaksiDto();
	        transaksiDto.setId(transaksi.getId());
	        transaksiDto.setNama(transaksi.getNama());
	        transaksiDto.setProductId(transaksi.getProduct().getId());
	        transaksiDto.setQuantity(transaksi.getQuantity());
	        transaksiDto.setCreatedAt(transaksi.getCreatedAt());

	        model.addAttribute("transaksiDto", transaksiDto);
	        model.addAttribute("products", productservice.getAllProducts()); // Untuk dropdown produk

	        return "transaksi/EditTransaksi";
	    }
	 
	 @PostMapping("/edit/{id}")
	    public String editTransaksi(
	            @Valid @ModelAttribute TransaksiDto transaksiDto,
	            BindingResult result,
	            Model model,
	            @PathVariable int id) {

	        if (result.hasErrors()) {
	            model.addAttribute("products", productservice.getAllProducts()); // Untuk dropdown produk
	            return "transaksi/EditTransaksi";
	        }

	        Transaksi transaksi = transaksirepo.findById(id)
	                .orElseThrow(() -> new IllegalArgumentException("Invalid transaksi ID: " + id));

	        transaksi.setNama(transaksiDto.getNama());
	        transaksi.setProduct(productservice.getProductById(transaksiDto.getProduct()));
	        transaksi.setQuantity(transaksiDto.getQuantity());
	        transaksi.setCreatedAt(transaksiDto.getCreatedAt());

	        transaksirepo.save(transaksi);

	        return "redirect:/transaksi";
	    }
	 
	 @PostMapping("/delete/{id}")
	    public String deleteTransaksi(@PathVariable int id) {
	        transaksirepo.deleteById(id);
	        return "redirect:/transaksi";
	    }
}
