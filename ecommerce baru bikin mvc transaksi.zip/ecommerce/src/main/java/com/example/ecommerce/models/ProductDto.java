package com.example.ecommerce.models;

import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

import java.util.Date;

public class ProductDto {

    private int id; 

    @NotEmpty(message = "Name is Required")
    private String name;

    @NotEmpty(message = "Brand is Required")
    private String brand;

    @NotEmpty(message = "Category is Required")
    private String category;

    @Min(0)
    private double price;

    @Size(min = 10, message = "Deskripsi memerlukan minimal 10 karakter")
    @Size(max = 2000, message = "Deskripsi tidak boleh melebihi 2000 karakter")
    private String description;

    private MultipartFile imageFile;

    private int stock;

    private Date createdAt;  // Added field

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public MultipartFile getImageFile() {
        return imageFile;
    }

    public void setImageFile(MultipartFile imageFile) {
        this.imageFile = imageFile;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date date) {
        this.createdAt = date;
    }

	public void setImageUrl(String string) {
		// TODO Auto-generated method stub
		
	}
}
