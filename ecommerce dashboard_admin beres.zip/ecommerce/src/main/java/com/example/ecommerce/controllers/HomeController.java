package com.example.ecommerce.controllers;

import com.example.ecommerce.models.UserDto;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/home")
public class HomeController {

    @GetMapping()
    public String home(Model model) {
        return "home";
    }

    // Users_________________________________________
    @GetMapping("/login")
    public String login(Model model) {
        return "login/User";
    }

    @GetMapping("/register")
    public String register(Model model) {
        model.addAttribute("userDto", new UserDto());
        return "login/RegisterUser";
    }

    @GetMapping("/about")
    public String about(Model model) {
        return "about";
    }

    @GetMapping("/shop")
    public String shop(Model model) {
        return "products/UserProduct";
    }

    // Admin__________________________________________
    @GetMapping("/admin")
    public String admin(Model model) {
        return "login/Admin";
    }

    @GetMapping("/createadmin")
    public String registeradmin(Model model) {
        return "login/RegisterAdmin";
    }
}
